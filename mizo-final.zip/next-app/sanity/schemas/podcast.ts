export default {
  name: 'podcast',
  title: 'Podcast',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title' } },
    { name: 'audio', title: 'Audio File', type: 'file' },
    { name: 'description', title: 'Description', type: 'text' },
    { name: 'publishedAt', title: 'Published at', type: 'datetime' }
  ]
};
