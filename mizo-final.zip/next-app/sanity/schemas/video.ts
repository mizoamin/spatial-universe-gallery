export default {
  name: 'video',
  title: 'Video',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title' } },
    { name: 'videoFile', title: 'Video File', type: 'file' },
    { name: 'thumbnail', title: 'Thumbnail', type: 'image' },
    { name: 'description', title: 'Description', type: 'text' }
  ]
};
