export default {
  name: 'album',
  title: 'Album',
  type: 'document',
  fields: [
    { name: 'title', title: 'Title', type: 'string' },
    { name: 'slug', title: 'Slug', type: 'slug', options: { source: 'title' } },
    { name: 'year', title: 'Year', type: 'number' },
    { name: 'images', title: 'Images', type: 'array', of: [{ type: 'image' }] },
    { name: 'description', title: 'Description', type: 'text' }
  ]
};
