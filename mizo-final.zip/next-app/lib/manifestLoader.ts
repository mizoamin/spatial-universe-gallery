import fs from 'fs/promises';
import path from 'path';

export type AssetRecord = {
  id: string;
  title?: string;
  alt?: string;
  description?: string;
  slug?: string;
  tags?: string[];
  keywords?: string[];
  location?: string;
  year?: string | number;
  geo?: { lat?: number; lon?: number } | string;
  urls: string[];
  type?: string;
  [k: string]: any;
};

const DATA_DIR = path.join(process.cwd(), 'next-app', 'data');
const FLAT_PATH = path.join(DATA_DIR, 'flat_assets.json');

export async function loadFlatAssets(): Promise<AssetRecord[]> {
  const raw = await fs.readFile(FLAT_PATH, 'utf8');
  const parsed = JSON.parse(raw) as AssetRecord[];
  return parsed;
}

export async function getAssetById(id: string): Promise<AssetRecord | undefined> {
  const all = await loadFlatAssets();
  return all.find(a => a.id === id || a.slug === id);
}

export async function getAssetsByTag(tag: string): Promise<AssetRecord[]> {
  const all = await loadFlatAssets();
  return all.filter(a => Array.isArray(a.tags) && a.tags.includes(tag));
}

export async function generateSitemapEntries(options?: { toWebp?: boolean, siteBase?: string }){
  const all = await loadFlatAssets();
  const base = options?.siteBase || '';
  const entries = all.map(a => {
    const urls = a.urls.map(u => {
      if(options?.toWebp) return u.replace(/\.(jpe?g|png|gif)$/i, '.webp');
      return u;
    });
    return {
      id: a.id,
      title: a.title || a.slug || '',
      loc: base + (a.slug ? `/${a.slug}` : `/asset/${a.id}`),
      images: urls,
      meta: {
        description: a.description || a.meta_description || '',
        keywords: a.keywords || a.tags || [],
        alt: a.alt || a.title || ''
      }
    };
  });
  return entries;
}

export default {
  loadFlatAssets, getAssetById, getAssetsByTag, generateSitemapEntries
};
