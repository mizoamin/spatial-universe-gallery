import create from 'zustand';

type AppState = {
  currentSection: string;
  isHovering: boolean;
  setSection: (s: string) => void;
  setHovering: (v: boolean) => void;
};

export const useAppStore = create<AppState>((set) => ({
  currentSection: 'home',
  isHovering: false,
  setSection: (s: string) => set(() => ({ currentSection: s })),
  setHovering: (v: boolean) => set(() => ({ isHovering: v })),
}));

export const SECTIONS = {
  LEGACY: 'Legacy',
  VENTURES: 'Ventures',
  VISION: 'Vision',
  ODYSSEY: 'Odyssey',
};

export default useAppStore;
