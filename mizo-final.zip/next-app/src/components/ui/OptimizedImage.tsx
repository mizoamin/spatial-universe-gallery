"use client";
import Image from 'next/image';
import React from 'react';

type Props = React.ComponentProps<typeof Image> & { blurDataURL?: string };

export default function OptimizedImage(props: Props) {
  const { alt = '', placeholder = 'empty', ...rest } = props;
  return <Image alt={alt} placeholder={placeholder as any} loading="lazy" {...(rest as any)} />;
}
