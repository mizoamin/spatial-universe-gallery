"use client";
import React from 'react';
import StarField from '../3d/StarField';

export default function LayoutShell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <div style={{ position: 'absolute', inset: 0, zIndex: -1 }}>
        <StarField />
      </div>
      <div className="relative z-10 min-h-screen">
        {children}
      </div>
    </>
  );
}
