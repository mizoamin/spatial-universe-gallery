"use client";
import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

export default function WarpVFX({ warpStrength = 0 }: { warpStrength: number }) {
  const points = useRef<THREE.Points | null>(null);
  const count = 240;
  const positions = useMemo(() => {
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      // spread in a cone in front of the camera
      arr[i * 3 + 0] = (Math.random() - 0.5) * 8;
      arr[i * 3 + 1] = (Math.random() - 0.5) * 4;
      arr[i * 3 + 2] = -Math.random() * 40; // z negative in front
    }
    return arr;
  }, []);

  const speeds = useMemo(() => Float32Array.from({ length: count }, () => 0.5 + Math.random() * 4), [] as any);

  useFrame((state, delta) => {
    if (!points.current) return;
    const geometry = points.current.geometry as THREE.BufferGeometry;
    const pos = geometry.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < count; i++) {
      const idx = i * 3 + 2;
      // move forward faster when warpStrength increases
      pos.array[idx] += delta * speeds[i] * (1 + warpStrength * 18);
      if (pos.array[idx] > 2) {
        pos.array[idx] = -40 - Math.random() * 10;
      }
    }
    pos.needsUpdate = true;
  });

  return (
    <points ref={points} frustumCulled={false}>
      <bufferGeometry>
        <bufferAttribute attachObject={["attributes", "position"]} array={positions} count={positions.length / 3} itemSize={3} />
      </bufferGeometry>
      <pointsMaterial size={0.18} color="#b6cfe0" sizeAttenuation transparent opacity={0.9} />
    </points>
  );
}
