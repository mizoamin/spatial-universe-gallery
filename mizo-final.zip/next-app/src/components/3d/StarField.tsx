"use client";
import React, { useMemo } from "react";
import { Canvas } from "@react-three/fiber";

function Stars() {
  const positions = useMemo(() => {
    const count = 4000;
    const arr = new Float32Array(count * 3);
    for (let i = 0; i < count; i++) {
      const r = 30 + Math.random() * 400;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const x = r * Math.sin(phi) * Math.cos(theta);
      const y = r * Math.sin(phi) * Math.sin(theta);
      const z = r * Math.cos(phi);
      const i3 = i * 3;
      arr[i3] = x;
      arr[i3 + 1] = y;
      arr[i3 + 2] = z;
    }
    return arr;
  }, []);

  return (
    <points>
      <bufferGeometry>
        <bufferAttribute
          attachObject={["attributes", "position"]}
          array={positions}
          count={positions.length / 3}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.7} color="#9fb7c9" sizeAttenuation />
    </points>
  );
}

export default function StarField() {
  return (
    <Canvas
      gl={{ antialias: true }}
      camera={{ position: [0, 0, 80], fov: 60 }}
      style={{ position: "absolute", inset: 0, zIndex: -1 }}
    >
      <ambientLight intensity={0.6} />
      <Stars />
    </Canvas>
  );
}
