// AvatarGLB component deprecated — using 2.5D billboard images instead.
// Left as a harmless stub to avoid build errors if referenced elsewhere.
"use client";
import React from 'react';

export default function AvatarGLB() {
  return null;
}
