"use client";
import React, { Suspense, useRef, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { OrbitControls, Html } from '@react-three/drei';
import PlanetarySystem from './PlanetarySystem';
import WarpVFX from './WarpVFX';
import { useSpring } from '@react-spring/three';
// Postprocessing (requires @react-three/postprocessing)
import { EffectComposer, Bloom, Vignette } from '@react-three/postprocessing';

function CameraRig({ target, warpStrength, spring }: { target: [number, number, number] | null; warpStrength: number; spring: any }) {
  const { camera } = useThree();
  const refTarget = useRef<[number, number, number] | null>(null);

  useFrame((_, delta) => {
    if (target) refTarget.current = target;
    // update camera from spring values
    const x = spring.x.get();
    const y = spring.y.get();
    const z = spring.z.get();
    camera.position.set(x, y, z);
    if (refTarget.current) {
      camera.lookAt(refTarget.current[0], refTarget.current[1], refTarget.current[2]);
    } else {
      camera.lookAt(0, 0, 0);
    }
    camera.updateProjectionMatrix();
  });

  return null;
}

export default function SpatialIntro() {
  const [warpTarget, setWarpTarget] = useState<[number, number, number] | null>(null);
  const [warpStrength, setWarpStrength] = useState(0);

  function WarpController({ setWarpStrength }: { setWarpStrength: (v: number | ((p: number) => number)) => void }) {
    useFrame((_, delta) => {
      setWarpStrength((s: number) => Math.max(0, s - delta * 0.9));
    });
    return null;
  }

  // spring for camera position
  const [spring, api] = useSpring(() => ({ x: 0, y: 1.5, z: 14, config: { mass: 1, tension: 120, friction: 24 } }));

  return (
    <div className="w-full h-screen">
      <Canvas camera={{ position: [0, 1.5, 14], fov: 50 }} style={{ height: '100vh' }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[10, 10, 5]} intensity={0.6} />
        <Suspense fallback={<Html center>Loading...</Html>}>
          <group>
            <PlanetarySystem
              onWarp={(_, pos) => {
                setWarpTarget(pos ?? null);
                setWarpStrength(1);
                if (pos) {
                  const desired = { x: pos[0] * 0.45, y: pos[1] + 2.2, z: pos[2] * 0.45 + 6 } as any;
                  api.start({ x: desired.x, y: desired.y, z: desired.z, config: { mass: 1, tension: 220, friction: 18 } });
                }
              }}
            />
          </group>
        </Suspense>

        {/* Camera rig uses springed position for smoother cinematic motion */}
        <CameraRig target={warpTarget} warpStrength={warpStrength} spring={spring} />

        {/* Warp controller will decay the warpStrength over time */}
        <WarpController setWarpStrength={setWarpStrength} />

        {/* Warp VFX: particle streaks that accelerate during warp */}
        <WarpVFX warpStrength={warpStrength} />

        {/* Postprocessing: bloom + vignette for cinematic look; intensities scale with warpStrength */}
        <EffectComposer>
          <Bloom luminanceThreshold={0.18} intensity={0.45 + warpStrength * 1.6} mipmapBlur levels={6} />
          <Vignette eskil={false} offset={0.35} darkness={1.2 + warpStrength * 1.4} />
        </EffectComposer>

        <OrbitControls enablePan={false} enableZoom={false} enableRotate={false} />
      </Canvas>
    </div>
  );
}
