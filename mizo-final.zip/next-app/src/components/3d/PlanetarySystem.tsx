"use client";
import React, { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { Billboard, useTexture } from '@react-three/drei';
import * as THREE from 'three';
import { useAppStore } from '../../lib/store';

type Planet = {
  id: string;
  name: string;
  color: string;
  distance: number;
  size: number;
};

const PLANETS: Planet[] = [
  { id: 'p-legacy', name: 'Legacy', color: '#ff8c42', distance: 9, size: 0.9 },
  { id: 'p-ventures', name: 'Ventures', color: '#9b5cff', distance: 13, size: 0.8 },
  { id: 'p-vision', name: 'Vision', color: '#4dd0e1', distance: 17, size: 0.85 },
  { id: 'p-odyssey', name: 'Odyssey', color: '#6ee7b7', distance: 21, size: 1.0 },
];

const BASE = 'https://raw.githubusercontent.com/mizoamin/mizo-assets-media-1/main/brand_assets/professional-headshots-and-profile-pics/';
const IDLE = `${BASE}mizo-state1-off.png`;
const HOVER = `${BASE}mizo-state2-ready.png`;
const ACTIVE = `${BASE}mizo-state3-active.png`;

export default function PlanetarySystem({ onWarp }: { onWarp?: (name: string, position?: [number, number, number]) => void }) {
  const group = useRef<THREE.Group | null>(null);
  const avatarRef = useRef<THREE.Mesh | null>(null);
  const planetRefs = useRef<Record<string, THREE.Mesh | null>>({});
  const setHovering = useAppStore((s) => s.setHovering);
  const setSection = useAppStore((s) => s.setSection);
  const [avatarState, setAvatarState] = useState<'idle' | 'hover' | 'active'>('idle');

  // load textures (PNG with alpha) — drei's useTexture handles caching
  const [idleTex, hoverTex, activeTex] = useTexture([IDLE, HOVER, ACTIVE]);

  useFrame((_, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.06;

    // avatar scale lerp for subtle pop
    const targetAvatarScale = avatarState === 'idle' ? 1 : avatarState === 'hover' ? 1.06 : 1.12;
    if (avatarRef.current) {
      const s = avatarRef.current.scale;
      s.x += (targetAvatarScale - s.x) * 0.12;
      s.y += (targetAvatarScale - s.y) * 0.12;
      s.z += (targetAvatarScale - s.z) * 0.12;
    }

    // planets subtle scale when hovering
    Object.keys(planetRefs.current).forEach((id) => {
      const m = planetRefs.current[id];
      if (!m) return;
      const target = (m.userData && m.userData.hovered) ? 1.12 : 1.0;
      m.scale.x += (target - m.scale.x) * 0.12;
      m.scale.y += (target - m.scale.y) * 0.12;
      m.scale.z += (target - m.scale.z) * 0.12;
    });
  });

  const currentMap = avatarState === 'idle' ? idleTex : avatarState === 'hover' ? hoverTex : activeTex;

  return (
    <group ref={group}>
      {/* Central 2.5D Billboard avatar */}
      <Billboard follow={true} lockX={false} lockY={false} position={[0, 0, 0]}>
        <mesh
          ref={(r) => (avatarRef.current = r)}
          onPointerOver={(e) => {
            e.stopPropagation();
            setAvatarState('hover');
            setHovering(true);
            (e.nativeEvent as any).target.style.cursor = 'pointer';
          }}
          onPointerOut={(e) => {
            e.stopPropagation();
            setAvatarState('idle');
            setHovering(false);
            (e.nativeEvent as any).target.style.cursor = '';
          }}
          onClick={(e) => {
            e.stopPropagation();
            setAvatarState('active');
            setSection('about');
          }}
        >
          <planeGeometry args={[3, 4]} />
          <meshBasicMaterial map={currentMap} transparent alphaTest={0.01} toneMapped={false} />
        </mesh>
      </Billboard>

      {/* Orbiting planets */}
      {PLANETS.map((p, i) => {
        const angle = (i / PLANETS.length) * Math.PI * 2;
        const x = Math.cos(angle) * p.distance;
        const z = Math.sin(angle) * p.distance;
        return (
          <mesh
            key={p.id}
            position={[x, 0, z]}
            ref={(r) => (planetRefs.current[p.id] = r)}
            userData={{ hovered: false }}
            onClick={() => {
              setSection(p.name);
              onWarp?.(p.name, [x, 0, z]);
            }}
            onPointerOver={(e) => {
              document.body.style.cursor = 'pointer';
              setHovering(true);
              if (planetRefs.current[p.id]) (planetRefs.current[p.id]!.userData = { hovered: true });
            }}
            onPointerOut={(e) => {
              document.body.style.cursor = '';
              setHovering(false);
              if (planetRefs.current[p.id]) (planetRefs.current[p.id]!.userData = { hovered: false });
            }}
          >
            <sphereGeometry args={[p.size, 32, 32]} />
            <meshStandardMaterial color={p.color} metalness={0.5} roughness={0.3} />
          </mesh>
        );
      })}
    </group>
  );
}
