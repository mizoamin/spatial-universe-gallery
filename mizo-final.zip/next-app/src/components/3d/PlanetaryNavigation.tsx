"use client";
import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useAppStore } from '../../lib/store';

type Planet = {
  id: string;
  name: string;
  color: string;
  distance: number;
  size: number;
};

const PLANETS: Planet[] = [
  { id: 'p-legacy', name: 'Legacy', color: '#ff8c42', distance: 18, size: 2.6 },
  { id: 'p-ventures', name: 'Ventures', color: '#9b5cff', distance: 26, size: 2.2 },
  { id: 'p-vision', name: 'Vision', color: '#4dd0e1', distance: 34, size: 2.4 },
  { id: 'p-odyssey', name: 'Odyssey', color: '#6ee7b7', distance: 42, size: 3.0 },
];

export default function PlanetaryNavigation({ onWarp }: { onWarp?: (planet: Planet, position?: [number, number, number]) => void }) {
  const group = useRef<THREE.Group | null>(null);
  const setSection = useAppStore((s) => s.setSection);

  useFrame((state, delta) => {
    if (group.current) group.current.rotation.y += delta * 0.08;
  });

  return (
    <group ref={group}>
      {PLANETS.map((p, i) => {
        const angle = (i / PLANETS.length) * Math.PI * 2;
        const x = Math.cos(angle) * p.distance;
        const z = Math.sin(angle) * p.distance;
        return (
          <mesh
            key={p.id}
            position={[x, 0, z]}
            onClick={() => {
              setSection(p.name);
              onWarp?.(p, [x, 0, z]);
            }}
            onPointerOver={(e) => (document.body.style.cursor = 'pointer')}
            onPointerOut={(e) => (document.body.style.cursor = '')}
          >
            <sphereGeometry args={[p.size, 48, 48]} />
            <meshStandardMaterial color={p.color} metalness={0.6} roughness={0.25} />
          </mesh>
        );
      })}
    </group>
  );
}
