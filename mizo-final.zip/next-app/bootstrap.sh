#!/usr/bin/env bash
set -euo pipefail

echo "== Bootstrap: ensure Node and install deps for next-app =="

if ! command -v node >/dev/null 2>&1; then
  echo "Node not found. Attempting to install Node 20 (requires sudo)..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

echo "Node version: $(node -v)"
echo "NPM version: $(npm -v)"

ROOT=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT"

echo "Cleaning potential nested node_modules and lockfiles..."
rm -rf node_modules package-lock.json
rm -rf next-app/next-app/node_modules next-app/next-app/package-lock.json || true

echo "Installing dependencies with legacy peer deps to avoid ERESOLVE conflicts..."
npm install --legacy-peer-deps

echo "Bootstrap complete. To run dev server:"
echo "  cd $ROOT && npm run dev"
