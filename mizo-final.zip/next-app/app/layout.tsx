import React from 'react';
import './globals.css';
import LayoutShell from '../src/components/ui/LayoutShell';

export const metadata = {
	title: 'Mizo Amin — Spatial Domain',
	description: 'A cinematic spatial gallery',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
	return (
		<html lang="en">
			<head>
				<link rel="preconnect" href="https://fonts.googleapis.com" />
				<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@200;400;600&display=swap" rel="stylesheet" />
				<meta name="viewport" content="width=device-width, initial-scale=1" />
			</head>
			<body className="h-screen overflow-hidden">
				<LayoutShell>
					<div className="min-h-screen h-screen w-full bg-void-black text-platinum">
						{children}
					</div>
				</LayoutShell>
			</body>
		</html>
	);
}
