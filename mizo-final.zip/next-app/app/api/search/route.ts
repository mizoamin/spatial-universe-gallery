import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  const { query } = body;

  // Placeholder: connect OpenAI + vector DB here to search image metadata
  // For now return an empty result skeleton
  return NextResponse.json({ query, results: [] });
}
