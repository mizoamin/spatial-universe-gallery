import React from 'react';
import SpatialIntro from '../src/components/3d/SpatialIntro';

export default function Page() {
  return (
    <main className="w-full h-screen">
      <SpatialIntro />
    </main>
  );
}
