#!/usr/bin/env bash
echo "GLB compression workflow has been canceled in this project."
echo "We now use 2.5D billboard images for the avatar. Place images under public/images/ and update components if needed."
