#!/usr/bin/env node
/*
  processManifest.js
  - Streams or parses `next-app/data/assets_manifest_v8.json`
  - Produces:
    - next-app/data/flat_assets.json  (flat array of asset records)
    - next-app/data/manifest_summary.json (summary stats)
    - next-app/data/manifest_validation.json (simple schema/field report)

  Usage: node scripts/processManifest.js
*/

const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
const MANIFEST_PATH = path.join(DATA_DIR, 'assets_manifest_v8.json');
const OUT_FLAT = path.join(DATA_DIR, 'flat_assets.json');
const OUT_SUM = path.join(DATA_DIR, 'manifest_summary.json');
const OUT_VAL = path.join(DATA_DIR, 'manifest_validation.json');

function safeString(v){
  if(v === undefined || v === null) return '';
  if(typeof v === 'string') return v;
  return String(v);
}

function isLikelyAsset(obj){
  if(!obj || typeof obj !== 'object') return false;
  // common keys: url, src, filename, file, path
  return ('url' in obj) || ('src' in obj) || ('file' in obj) || ('filename' in obj) || ('path' in obj);
}

function extractFromObject(obj, ctx){
  // ctx: album path or container
  const record = {};
  // copy all primitive props
  for(const k of Object.keys(obj)){
    const v = obj[k];
    if(typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') record[k] = v;
    else if(Array.isArray(v)) record[k] = v;
  }
  if(ctx) record._album = ctx;
  return record;
}

function walk(obj, ctx, collector, fieldSet){
  if(!obj || typeof obj !== 'object') return;
  if(Array.isArray(obj)){
    for(const it of obj) walk(it, ctx, collector, fieldSet);
    return;
  }
  // If object looks like asset, extract
  if(isLikelyAsset(obj)){
    const rec = extractFromObject(obj, ctx);
    collector.push(rec);
    for(const k of Object.keys(rec)) fieldSet.add(k);
  }
  // Recurse into properties
  for(const k of Object.keys(obj)){
    const v = obj[k];
    if(typeof v === 'object' && v !== null){
      // treat some keys as context (album, folder, location)
      if(/album|folder|collection|path|location|year|slug/i.test(k) && (typeof v === 'string' || typeof v === 'number')){
        // skip — primitive handled above
      }
      walk(v, ctx, collector, fieldSet);
    }
  }
}

function summarize(list, fieldSet){
  const summary = {
    totalAssets: list.length,
    sampleCount: Math.min(10, list.length),
    fields: Array.from(fieldSet).sort(),
    examples: list.slice(0,10),
    tagsCount: {},
    years: {},
    locations: {},
  };
  for(const it of list){
    if(it.tags && Array.isArray(it.tags)){
      for(const t of it.tags){ summary.tagsCount[t] = (summary.tagsCount[t]||0)+1 }
    }
    if(it.year) summary.years[it.year] = (summary.years[it.year]||0)+1;
    if(it.location) summary.locations[it.location] = (summary.locations[it.location]||0)+1;
  }
  return summary;
}

function validate(list, fieldSet){
  // Basic validation: required fields / field types
  const required = ['url','title','alt','slug'];
  const report = { total: list.length, missingCounts: {}, samples: [] };
  for(const r of required) report.missingCounts[r] = 0;
  for(let i=0;i<Math.min(1000,list.length);i++){
    const it = list[i];
    for(const r of required){ if(!(r in it)) report.missingCounts[r]++; }
    if(i<10) report.samples.push(it);
  }
  return report;
}

function fallbackParse(){
  console.log('FALLBACK: reading whole file into memory (may be large)');
  const raw = fs.readFileSync(MANIFEST_PATH, 'utf8');
  const obj = JSON.parse(raw);
  const collector = [];
  const fieldSet = new Set();
  walk(obj, null, collector, fieldSet);
  return {collector, fieldSet};
}

async function main(){
  if(!fs.existsSync(MANIFEST_PATH)){
    console.error('Manifest not found at', MANIFEST_PATH);
    process.exit(1);
  }
  let collector = [];
  let fieldSet = new Set();

  // Try streaming parser if available
  try{
    const {parser} = require('stream-json');
    const {streamArray} = require('stream-json/streamers/StreamArray');
    console.log('Using stream-json streamer (assuming root array)');
    const rs = fs.createReadStream(MANIFEST_PATH, {encoding:'utf8'});
    await new Promise((resolve,reject)=>{
      const pipeline = rs.pipe(parser());
      pipeline.on('data', ({name, value})=>{
        // value tokens may be complex; ignore
      });
      // fallback to full parse via readFile once end
      pipeline.on('end', async ()=>{
        // stream-json approach requires knowing the structure; do fallback parse for robust extraction
        const out = fallbackParse(); collector = out.collector; fieldSet = out.fieldSet; resolve();
      });
      pipeline.on('error', err=>{ console.warn('stream-json error', err); const out = fallbackParse(); collector = out.collector; fieldSet = out.fieldSet; resolve(); });
    });
  }catch(e){
    // Not installed or error — fallback
    const out = fallbackParse(); collector = out.collector; fieldSet = out.fieldSet;
  }

  console.log('Assets collected:', collector.length);
  // Normalize minimal fields for each record
  const flat = collector.map((it, idx)=>{
    const rec = Object.assign({}, it);
    rec.id = rec.id || rec.slug || ('asset-' + idx);
    // normalize url fields
    if(rec.url && typeof rec.url === 'string') rec.urls = [rec.url];
    else if(rec.src && typeof rec.src === 'string') rec.urls = [rec.src];
    else if(rec.files && Array.isArray(rec.files)) rec.urls = rec.files.map(f=>safeString(f));
    else rec.urls = [];
    // derive type
    if(rec.urls.some(u=>/\.(jpg|jpeg|png|webp|gif)$/i.test(u))) rec.type = 'image';
    else if(rec.urls.some(u=>/\.(mp4|mov|webm|ogg)$/i.test(u))) rec.type = 'video';
    else rec.type = rec.type || 'unknown';
    return rec;
  });

  const summary = summarize(flat, fieldSet);
  const validation = validate(flat, fieldSet);

  fs.writeFileSync(OUT_FLAT, JSON.stringify(flat, null, 2), 'utf8');
  fs.writeFileSync(OUT_SUM, JSON.stringify(summary, null, 2), 'utf8');
  fs.writeFileSync(OUT_VAL, JSON.stringify(validation, null, 2), 'utf8');

  console.log('Wrote:', OUT_FLAT, OUT_SUM, OUT_VAL);
}

main().catch(err=>{ console.error(err); process.exit(1); });
