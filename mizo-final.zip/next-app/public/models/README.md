This project now uses 2.5D billboarding for the avatar using three PNG states (idle / hover / active).

Place the three profile PNGs in `public/images/` or let the app continue to load them from the provided raw GitHub URLs.

Files:
- `mizo-state1-off.png` — idle
- `mizo-state2-ready.png` — hover
- `mizo-state3-active.png` — active

If you later want to add GLB support again, we can reintroduce a DRACO workflow — for now this README documents the image-first approach.
