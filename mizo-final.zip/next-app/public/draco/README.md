DRACO workflow deprecated — this folder is unused.

We now use 2.5D billboard images for the avatar. You can safely ignore or remove these files.
